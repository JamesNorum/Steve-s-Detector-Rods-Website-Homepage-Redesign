# Steve's-Detector-Rods-Website-Homepage-Redesign

Welcome to the redesign of Steve's Detector Rods!

## Getting Started

1. Install npm (node package manager)
2. In a terminal, navigate to this folder
3. Run the following commands:

```
nvm use
npm i
```

4. Navigate to:

```
{LOCAL_PATH_TO_REPO}/index.html
```
